from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from random import randint

class SetupScreen(Screen):
    pass

class GameScreen2(Screen):
    pass

class GameScreen3(Screen):
    pass

class GameScreen4(Screen):
    pass

class GameScreen5(Screen):
    pass

class GameScreen6(Screen):
    pass

class ManaScreen(Screen):
    pass

class DiceScreen(Screen):
    pass

class Commander2(Screen):
    pass

class Commander3(Screen):
    pass

class Commander4(Screen):
    pass

class Commander5(Screen):
    pass

class Commander6(Screen):
    pass

class WindowManager(ScreenManager):
    def __init__(self, **kwargs):
        super(WindowManager, self).__init__(**kwargs)
        self.start_x = 0
        self.start_y= 0
        self.transition= SlideTransition()
    def on_touch_down(self, touch):
        self.start_x = touch.x
        self.start_y = touch.y
        return super(WindowManager, self).on_touch_down(touch)
    def on_touch_up(self, touch):
        if touch.x - self.start_x < -100 and self.current_screen.name == f'game{magic_app.players}':
            self.transition.direction= 'left'
            self.current = 'mana'
        elif touch.x - self.start_x > 100 and self.current_screen.name == 'mana':
            self.transition.direction= 'right'
            self.current = f'game{magic_app.players}'
        elif touch.y - self.start_y > 100 and self.current_screen.name == f'game{magic_app.players}':
            self.transition.direction= 'up'
            self.current = 'dice'
        elif touch.y - self.start_y < -100 and self.current_screen.name == 'dice':
            self.transition.direction= 'down'
            self.current = f'game{magic_app.players}'
        elif touch.x - self.start_x > 100 and self.current_screen.name == f'game{magic_app.players}':
            self.transition.direction= 'right'
            self.current = f'com{magic_app.players}'
            for i in range(magic_app.players):
                if magic_app.names[i+1] != '':
                    self.get_screen(f'com{magic_app.players}').ids[f'pl{i+1}'].text= str(magic_app.names[i+1])
                else:
                    self.get_screen(f'com{magic_app.players}').ids[f'pl{i+1}'].text= f'Player{i+1}'
        elif touch.x - self.start_x < -100 and self.current_screen.name == f'com{magic_app.players}':
            self.transition.direction= 'left'
            self.current = f'game{magic_app.players}'
        return super(WindowManager, self).on_touch_up(touch)


class magic_app(MDApp):
    players= 0
    pl_lp= 0
    lifep= 0
    names= [0,'','','','','','']
    player= [0,0,0,0,0,0,0]
    mana= [0,0,0,0,0,0]
    rtp= True

    def build(self):
        self.title= 'MTG LP'
        self.theme_cls.theme_style= 'Dark'
        self.kv= Builder.load_file('main.kv')
        return self.kv

    def set_players(self, n):
        self.players= n
        magic_app.players= n
        sel_players= ['2','3','4','5','6']
        for i in range(5):
            if sel_players[i] != self.players:
                self.root.get_screen("setup").ids[f'bt{sel_players[i]}'].md_bg_color= [34/255, 177/255, 199/255, 1]
        self.root.get_screen("setup").ids[f'bt{self.players}'].md_bg_color= [0, 38/255, 77/255, 1]
        self.root.get_screen("setup").ids.rtp.disabled= False
    
    def set_game(self):
        self.lifep= int(self.lifep)
        for i in range(len(self.player)):
            self.player[i]= int(self.lifep)
        self.root.current= f'game{self.players}'
        for i in range(self.players):
            self.root.get_screen(f'game{self.players}').ids[f'count{i+1}'].text= str(self.player[i+1])
    
    def increase(self, g, p):
        self.player[g] += p
        self.root.get_screen(f'game{self.players}').ids[f'count{g}'].text= str(self.player[g])

    def decrease(self, g, p):
        self.player[g] -= p
        if self.player[g] < 0:
            self.player[g]= 0
            self.root.get_screen(f'game{self.players}').ids[f'count{g}'].text= str(self.player[g])
        else:
            self.root.get_screen(f'game{self.players}').ids[f'count{g}'].text= str(self.player[g])
    
    def mana_set(self, g, p):
        if p == '-':
            if self.mana[g] == 0:
                pass
            else:
                self.mana[g] -= 1
                self.root.get_screen('mana').ids[f'mana{g}'].text= str(self.mana[g])
        if p == '+':
            self.mana[g] += 1
            self.root.get_screen('mana').ids[f'mana{g}'].text= str(self.mana[g])

    def reset_mana(self):
        self.mana= [0,0,0,0,0,0]
        for i in range(len(self.mana)):
            self.root.get_screen('mana').ids[f'mana{i}'].text= str(self.mana[i])
    
    def d20(self):
        a= randint(1,20)
        self.root.get_screen('dice').ids['di20'].text= str(a)

    def d6(self):
        a= randint(1,6)
        self.root.get_screen('dice').ids['di6'].text= str(a)

    def mon(self):
        a= randint(1,10)
        if a % 2 == 0:
            self.root.get_screen('dice').ids['moneta'].text= 'head'
        else:
            self.root.get_screen('dice').ids['moneta'].text= 'tail'

if __name__ == "__main__":
    magic_app().run()