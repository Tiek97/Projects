import socket
import time
import random


UDP_IP= "127.0.0.1"
UDP_PORT= 5005
UDP_PORT2= 5006
UDP_PORT3= 5007
bufflen= 548

def listen():
    
    sock.bind((UDP_IP, UDP_PORT3))
    addr= sock.recv(bufflen)
    strGo=addr.decode()
    #if strGo=='go!':
    if strGo=="stop it!":
        a=False
    



def write():
    
    n=random.randint(0,10)
    s=str(n)
    a=s.encode()
    sock.sendto(a,(UDP_IP, UDP_PORT2))
    print(a)
    
  


sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
    
    sock.bind((UDP_IP, UDP_PORT))
    addr=sock.recv(bufflen)
    strGo=addr.decode()
    if strGo=="let's go bro!":
        break

a= True

while a==True:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    listen()
    write()

        
sock.close()