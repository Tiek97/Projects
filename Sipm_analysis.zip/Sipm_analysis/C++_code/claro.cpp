#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

void finder(vector<string>& str){
    /*La funzione accede al file contenente le variabili dei percorsi, 
    le separa e le stocca in un vettore.*/

    //Apertura del file con le variabili dei percorsi.
    ifstream file("data_found.txt");
    string line;

    if (file.is_open()){
        //Lettura delle righe e divisione della stringa.
        while (getline(file, line)) { 
            
            size_t pos= 0;
            string div= ",";
            string word;
            //Stoccaggio dei dati trovati in un vector.
            while((pos= line.find(div)) != string::npos){

                word= line.substr(0, pos);
                str.push_back(word);
                line.erase(0, pos + div.length());
            }
            
            str.pop_back();
            
         }
        
        file.close();
        str.erase(str.begin(), str.begin()+5);

    }

    else cout << "unable to read the file." << endl;

}

void reader(vector<float>& fpt, vector<float>& fat, vector<float>& xd, vector<float>& yd, vector<int>& cnt, vector<string>& p) {
    /*La funzione completa i percorsi ai file, li legge e 
    inserisce il contenuto in un array provvisorio (con solo i dati
    dell'iterazione corrente) per poi dividere i dati nei vettori 
    indicati per le future operazioni.*/

    int c= 0;
    //Loop per l'accesso ai file.
    while (c < p.size()){

        ifstream input ("../secondolotto_1/Station_"+p[c]+"__"+p[c+1]+"/Station_"+p[c]+"__"+p[c+1]+"_Summary/Chip_"+p[c+2]+"/S_curve/Ch_"+p[c+4]+"_offset_"+p[c+3]+"_Chip_"+p[c+2]+".txt");
        string line;
        vector<float> sep;
        int j= 0;
        if (input.is_open()){
            //Divisione delle stringhe per trovare i dati.
            while (getline(input, line)) { 
                
                size_t pos= 0;
                string div= "\t";
                string word;
                float i= 0;
                //Cambio di variabile per i dati x, y, PT e AT e stoccaggio in un vettore provvisorio.
                while((pos= line.find(div)) != string::npos){

                    word= line.substr(0, pos);
                    stringstream g(word);
                    g >> i;
                    sep.push_back(i);
                    line.erase(0, pos + div.length());
                }
                
                stringstream g(line);
                g >> i;
                sep.push_back(i);

            }
            //Stoccaggio dei dati nei rispettivi vector.
            fpt.push_back(sep[1]);
            fat.push_back(sep[2]);
            int t= 0;

            while((5+t) < sep.size()){

                xd.push_back(sep[5+t]);
                yd.push_back(sep[6+t]);
                t= t+3;
                j++;

            }

            cnt.push_back(j);

        }
        
        else cout << "unable to read the file." << endl;
        input.close();
        c= c+5;
        
    }
    
}

void calculate(vector<float>& fpt, vector<float>& fat, vector<float>& lpt, vector<float>& lat, vector<float>& xd, vector<float>& yd, vector<int>& cnt) {
    /*La funzione procede all'analisi dei dati attraverso
    un fit lineare dei punti di ogni canale dei vari chip,
    calcola punto e ampiezza di transizione che tiene in 
    memoria attraverso due vettori e li scrive in un file.
    Infine procede al calcolo della media dei PT e AT di file
    e fit per poi scriverli al termine di "Claro_results.txt" 
    per avere un rapido riscontro della differenza tra i due.*/

    int dc= 0;
    int i= 0;
    int j= 0;
    //Apertura di un file per scrivere i PT e AT calcolati e dei file su colonne.
    ofstream results;
    results.open("Claro_results.txt");
    results << "l_trans_P   l_trans_A   f_trans_P   f_trans_A" << endl;

    while (dc < xd.size()){

        float x1;
        float x2;
        float y1;
        float y2;
        //Definizione dei punti per il calcolo del fit lineare.
        while(i< i+cnt[j]){

            if (yd[i]> 20){

                break;

            }

            i++;

        }

        if (yd[i+1] > 985 && xd[i]-xd[i-1]>= 3 && xd[i+1]-xd[i]<= 2){

            x1= xd[i-1];
            x2= xd[i];
            y1= yd[i-1];
            y2= yd[i];

        }

        else{

            x1= xd[i];
            x2= xd[i+1];
            y1= yd[i];
            y2= yd[i+1];

        }
        //Calcolo del fit lineare.
        float D= (2.0*(pow(x1, 2.0)+pow(x2, 2.0))-(pow(x1+x2, 2.0)));
        float A= ((pow(x1, 2.0)+pow(x2, 2.0))*(y1+y2)-(x1+x2)*(x1*y1+x2*y2))/D;
        float B= (2.0*(x1*y1+x2*y2)-(x1+x2)*(y1+y2))/D;
        float xm= (500-A)/B;
        float xmax= (1000-A)/B;
        float xmin= (0-A)/B;
        float xamp= xmax-xmin;
        //Stoccaggio dei dati calcolati in vector.
        lpt.push_back(xm);
        lat.push_back(xamp);
        //Scrittura dei PT e AT nel file.
        results << xm << "     " << xamp << "     " << fpt[j] << "     "  << -fat[j] << endl;

        dc= dc+cnt[j];
        i= dc;
        j++;

    }
 
    int n= 0;
    int l= 0;
    float f_ptm= 0;
    float f_atm= 0;
    float l_ptm= 0;
    float l_atm= 0;
    //Somma dei valori nei vector dei PT e AT calcolati e dei file.
    while(n< fpt.size()){

        f_ptm= f_ptm+fpt[n];
        f_atm= f_atm+fat[n];
        //Selettore di dati (elimina i -inf e -nan).
        if (isnan(lat[n]) || isinf(lpt[n])){
            l++;

        }

        else{

            l_ptm= l_ptm+lpt[n];
            l_atm= l_atm+lat[n];

        }

        n++;

    }
    //Calcolo delle medie.
    f_ptm= f_ptm/fpt.size();
    f_atm= -(f_atm/fpt.size());
    l_ptm= l_ptm/(fpt.size()-l);
    l_atm= l_atm/(fpt.size()-l);

    //Scrittura su file dei risultati.
    results << "\n\nFile TP and TA mean: " << f_ptm << ", " << f_atm << endl;
    results << "l_fit TP and TA mean: " << l_ptm << ", " << l_atm << endl;
    results.close();
    
}

int main(){
    //Definizione dei vettori per lo stoccaggio dei dati.
    vector<string> v;
    vector<int> ct;
    vector<float> x;
    vector<float> y;
    vector<float> f_pt;
    vector<float> f_at;
    vector<float> l_pt;
    vector<float> l_at;

    //Chiamate alle funzioni e print di controllo.
    cout << "Finding paths to files..." << endl;
    finder(v);
    cout << "Finding data..." << endl;
    reader(f_pt, f_at, x, y, ct, v);
    cout << "Analyzing data..." << endl;
    calculate(f_pt, f_at, l_pt, l_at, x, y, ct);
    cout << "\nENDED! You can find all in the file \"Claro_results.txt\".\n" << endl;

}