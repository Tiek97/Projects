import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize
import scipy.signal as sp
import progressbar

data_results= np.ndarray(shape= (6,3))
dcr_range= [0.58, 0.84, 0.0102]

class sipm_analyzer():
    #Definisco il metodo costruttore.

    def __init__(self, ov):

        self.table_time= time_reader('r20'+str(ov)+'ov.csv', 'X: (s)')
        self.table_wf= wf_reader('r20'+str(ov)+'ovwav.csv', 'TIME')
        self.table_time.rename(columns={'X: (s)':'ev', 'Y: (Hits)':'dt'}, inplace= True)
        self.points= int(len(self.table_wf)/len(self.table_time))
        self.num_val= len(self.table_time)
        self.table_time['t']= np.r_[0, self.table_time['dt'].iloc[1:]].cumsum()
        self.wf_peaks= pd.DataFrame()
        

    def event_wf(self, event, bsl, peak_h= 0.002, peak_p= 0.0001):
        #Questo metodo permette di graficare gli n eventi di una waveform e il calcolo dei picchi.

        #Selezione dei dati per la creazione dei grafici dei picchi e calcolo del numero di eventi.
        idx= [event*self.points, event*self.points+self.points]
        time= self.table_time['t'].iloc[event]+ self.table_wf['TIME'][idx[0]:idx[1]]
        chan= - self.table_wf['CH1'][idx[0]:idx[1]]

        self.baseline= np.polyfit(time[0:bsl], chan[0:bsl], 0)[0]
        bsl_time= time[0:bsl]
        bsl_chan= [self.baseline]*bsl

        #Funzione per il calcolo dei picchi.
        peaks, ndarray= sp.find_peaks(chan, height= peak_h, prominence= peak_p)

        #Definizione dei plot.
        fig, ax= plt.subplots()
        plt.ticklabel_format(axis='x', style= 'sci', scilimits=(0,0))
        ax.plot(time, chan, linestyle= '-', linewidth= 1)
        ax.plot(bsl_time, bsl_chan, linestyle= '-', linewidth= 1, c= 'darkgreen')
        ax.scatter(time.iloc[peaks], chan.iloc[peaks], c= 'darkred')
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Amplitude(V)')
        plt.tight_layout()

        #Selettore per il numero di picchi nella waveform.
        if len(peaks)>0 and len(peaks)<5:
            plt.close(fig)
            return time.iloc[peaks], chan.iloc[peaks]-self.baseline
        else:
            plt.close(fig)
            return time.iloc[peaks[:1]], chan.iloc[peaks[:1]]-self.baseline
            
            

    def analyze_wf(self, bsl, peak_h, peak_p):
        #Questo metodo permette di stoccare in un dataframe i picchi e i tempi nei quali 
        #avvengono per il futuro utilizzo e restituisce il numero di picchi trovati.

        print('Analyzing to get max...\n')

        #Loop sugli eventi.
        for event in self.table_time['ev']:
            peaks_t, peaks_a= self.event_wf(event, bsl, peak_h, peak_p)
            if peak_h<0.01:
                self.wf_peaks= pd.concat([self.wf_peaks, pd.DataFrame({'t': peaks_t, 'A': peaks_a})], ignore_index= True)
        print('Waveform analysis completed.\n')

        #Ricavo il dt dai tempi assoluti.
        self.wf_peaks['dt']= self.wf_peaks['t'].diff()
        self.wf_peaks= self.wf_peaks.iloc[1:]
        print('Found {:d} peaks.'.format(len(self.wf_peaks)))

    def plot_peaks(self, ov):
        #Questo metodo permette di graficare tutti i picchi in un plot (Dark current plot)
        #al fine di identificare le zone di dc, ap e ct. Contiene anche un istogramma 
        #rappresentante il numero di eventi in un dato intervallo di tempo.

        print('Plotting peaks...\n')

        #Creazione di un plot per ottenere i valori centrali dei bin di dt per poi distruggerla.
        fdummy, xdummy= plt.subplots()
        bin_c, bins, _ = xdummy.hist(self.wf_peaks['dt'], alpha= 0, bins= 100)
        plt.close(fdummy)

        #Definizione del grafico di dark current.
        fig, ax= plt.subplots(2, sharex= True)
        plt.xscale('log')
        fig_tit= 'Dark current plot ov_{:d}'.format(ov)
        ax[0].set_title(fig_tit)
        ax[0].scatter(self.wf_peaks['dt'], self.wf_peaks['A'], marker= 'o', facecolors= 'none', edgecolors= 'black')
        ax[0].set_xlim([1e-10, 10])
        ax[0].set_ylim([0, 0.020])
        ax[0].set_ylabel('Amplitude (V)')
        ax[0].text(1e-9, 0.017, 'N_peaks= {:d}'.format(len(self.wf_peaks)))

        log_bins= np.logspace(np.log10(bins[0]), np.log10(bins[-1]), len(bins))
        bin_c, _, _ = ax[1].hist(self.wf_peaks['dt'], bins= log_bins, histtype= 'step')
        bin_max= max(bin_c)*1.5
        ax[1].hist(self.wf_peaks['dt'], alpha= 0, bins= 100)
        ax[1].set_yscale('log')
        ax[1].set_ylabel('counts')
        ax[1].set_xlabel(r'$\Delta$t (s)')

        plt.tight_layout()
        plt.subplots_adjust(hspace= 0)

        plt.show()
    
    def calculator(self, ov):
        #Questo metodo calcola i risultati di dcr, apr e ctr dei vari overvoltage con
        #i relativi errori, restituendoli al terminale.

        print('Calculating dcr, apr, ctr...\n')
        
        #Calcolo dei risultati.
        dcr= len(self.wf_peaks[self.wf_peaks['dt']> 4e-6])
        dcr_err= np.sqrt(dcr)

        ctr= len(self.wf_peaks[self.wf_peaks['A']> dcr_range[ov-3]])
        ctr_err= np.sqrt(ctr)

        apr= len(self.wf_peaks[(self.wf_peaks['dt']< 4e-6) & (self.wf_peaks['A']< dcr_range[ov-3])])
        apr_err= np.sqrt(apr)

        runtime= self.wf_peaks['t'].iloc[-1]
        dcr= dcr/runtime
        data_results[0, ov-3]= dcr
        dcr_err= dcr_err/runtime
        data_results[1, ov-3]= dcr_err
        ctr= ctr/runtime
        data_results[2, ov-3]= ctr
        ctr_err= ctr_err/runtime
        data_results[3, ov-3]= ctr_err
        apr= apr/runtime
        data_results[4, ov-3]= apr
        apr_err= apr_err/runtime
        data_results[5, ov-3]= apr_err

        print("""
Dark count rate= {:.4f} +/- {:.4f} 1/s
After pulse rate= {:.4f} +/- {:.4f} 1/s
Cross talk rate= {:.4f} +/- {:.4f} 1/s
        """.format(dcr, dcr_err, apr, apr_err, ctr, ctr_err))

#Le seguenti helper function servono per accedere ai file dati
#e leggere le tabelle in essi contenute.
        
def time_reader(filename, key):

    with open(filename,'r') as data:
        lines= data.readlines()

    n= 0
    while n != len(lines) -1:
        if lines[n].startswith(key):
            return pd.read_csv(filename, header= n)
            
        n +=1

def wf_reader(filename, key):

    with open(filename,'r') as data:
        lines= data.readlines()

    n= 0
    while n != len(lines) -1:
        if lines[n].startswith(key):
            return pd.read_csv(filename, header= n-1)
            
        n +=1

def results():
    #Questa helper function restituisce tre grafici di comparazione tra
    #i risultati di ctr, apr e dcr dei vari overvoltage.

    #Definizione delle variabili x.
    names = ['ov3', 'ov4', 'ov5']

    #Definizione dei plot finali.
    plt.figure(figsize=(9, 3))

    a= plt.subplot(131)
    a.set_ylabel(r'Rate (Hz)')
    plt.title('Dark count rate')
    plt.scatter(names, data_results[0,:])
    plt.errorbar(names, data_results[0,:], yerr= data_results[1,:])

    plt.subplot(132)
    plt.title('Cross talk rate')
    plt.scatter(names, data_results[2,:])
    plt.errorbar(names, data_results[2,:], yerr= data_results[3,:])

    plt.subplot(133)
    plt.title('After pulse rate')
    plt.scatter(names, data_results[4,:])
    plt.errorbar(names, data_results[4,:], yerr= data_results[5,:])

    
    plt.show()