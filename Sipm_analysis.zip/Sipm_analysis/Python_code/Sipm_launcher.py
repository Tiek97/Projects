#Questo file permette, importando quello contenente la classe
#e le helper function, di lanciare il programma chiamando solo
#il necessario, rendendo più facile il cambio di eventuali parametri
#e l'utilizzo da parte dei fruitori non interessati ai processi
#svolti dal programma.
 
from Sipm import *

ov= 3

sipm_wf= sipm_analyzer(ov)

while ov <6:
    sipm_wf.__init__(ov)

    sipm_wf.analyze_wf(500, 0.002, 0.0001)

    sipm_wf.plot_peaks(ov)

    sipm_wf.calculator(ov)

    ov +=1

results()
print(data_results)