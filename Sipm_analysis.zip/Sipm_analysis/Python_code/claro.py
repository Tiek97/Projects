import pandas as pd
import matplotlib.pyplot as plt
from scipy.special import erf
from scipy.optimize import curve_fit
import numpy as np
import math

class analyzer():
    #Definisco la classe.

    def __init__(self):
        #Definisco il metodo costruttore.

        self.ref=[]
        self.data= pd.DataFrame(columns= list('XY'))
        self.num= pd.DataFrame(columns= list('CL'))
        self.f_res= pd.DataFrame()
        self.l_res= pd.DataFrame()
        self.c_res= pd.DataFrame()

    def linear(self, x, a, b):
        #Metodo di classe contenente la funzione erf modificata per il calcolo del curve fit.

        return (500*erf((x-a)/(b)))+500


    def reader(self, filename):
        #Metodo di lettura del file contenente le variabili dei percorsi.

        with open(filename, 'r') as file:
            lines= file.readlines()
        for line in lines:
            splitter= line.split(',')
            splitter= splitter[:5]
            self.ref.append(splitter)
        self.ref= self.ref[1:]

    def finder(self, filename):
        #Metodo per l'accesso ai file, lettura e stoccaggio dei dati.
        
        i= 0
        #Lettura del file delle variabili ai path.
        self.reader(filename)
        gen_path= '../secondolotto_1/Station_{:s}__{:s}/Station_{:s}__{:s}_Summary/Chip_{:s}/S_curve/Ch_{:s}_offset_{:s}_Chip_{:s}.txt'
        
        #Ciclo di apertura dei file e stoccaggio dati.
        while i< len(self.ref):
            data_list= []
            path= gen_path.format(self.ref[i][0], self.ref[i][1], self.ref[i][0], self.ref[i][1], self.ref[i][2], self.ref[i][4], self.ref[i][3],self.ref[i][2])
            with open(path) as points:
                d= points.readlines()
            pt_at= d[0].split('\t')
            self.f_res= self.f_res.append({'PT': float(pt_at[1]), 'AT': -float(pt_at[2].strip('\n'))}, ignore_index= True)

            for line in d:
                a= line.split('\t')
                data_list.append(a[:2])
            
            data_list= data_list[3:]
            self.num= self.num.append({'S': self.ref[i][1], 'C': self.ref[i][2], 'L': len(data_list)}, ignore_index= True)
            data_list= pd.DataFrame(data_list, columns=list('XY'))
            self.data= self.data.append(data_list, ignore_index= True)
            
            i+=1
        self.data= self.data.astype('int32')

    def plotter(self):
        #Metodo per il calcolo dei PT e AT e per creare i grafici dei vari chip.

        plot_count= 0
        chip= self.num['C'][0]
        c= 0
        j= 0
        diff= 0

        #Iterazioni sui canali dei chip.
        while plot_count< len(self.num)-1:

            row= 0
            col= 0
            i=0

            #Estrapolazione degli n canali del chip
            while chip== self.num['C'][plot_count]:
                if plot_count == len(self.num)-1:
                    plot_count+=1
                    break
                plot_count+=1
                
            if plot_count != len(self.num):
                chip= self.num['C'][plot_count]
            else:
                chip= self.num['C'][plot_count-1]

            #Definizione della struttura dei grafici
            fig, ax= plt.subplots(2,4, figsize= (10, 6))
            fig.suptitle('Station_{:s}/Chip_{:s}'.format(self.num['S'][plot_count-1],
             self.num['C'][plot_count-1]), y= 0.995)
            
            #Ciclo per il calcolo e i grafici dei PT e AT dei chip.
            for i in range(plot_count-diff):

                p= c
                #Ciclo per trovare i punti di transizione del fit lineare.
                while p< c+self.num['L'][j]:
                    if self.data['Y'][p] > 20:
                        break
                    p+=1

                    if self.data['Y'][p+1]>985 and self.data['X'][p]-self.data['X'][p-1]<= 3 and self.data['X'][p+1]-self.data['X'][p]<= 2:
                        p1= p-1
                        p2= p+1
                    else:
                        p1= p 
                        p2= p+2

                #Costruzione del plot del channel.
                ax[row, col].plot(self.data['X'][c : c+self.num['L'][j]], self.data['Y'][c : c+self.num['L'][j]], marker= 'o')
                
                #Calcolo del fit lineare.
                m, q= np.polyfit(self.data['X'][p1:p2], self.data['Y'][p1:p2], 1)
                x= self.data['X'][c: c+self.num['L'][j]]
                y= m*self.data['X'][c: c+self.num['L'][j]]+q
                pt= (500-q)/m
                at= ((1000-q)/m)-((0-q)/m)
                
                #Stoccaggio dei dati considerati idonei.
                if pt > 0 and pt < 350:
                    self.l_res= self.l_res.append({'PT': pt, 'AT': at}, ignore_index= True)

                #Calcolo col metodo erf/curve_fit.
                constants= curve_fit(self.linear, self.data['X'][c : c+self.num['L'][j]],
                self.data['Y'][c : c+self.num['L'][j]], bounds=((self.data['X'][c], 0),
                (self.data['X'][c+self.num['L'][j]-1],1000)))
                af= constants[0][0]
                bf= constants[0][1]
                self.c_res= self.c_res.append({'PT': af, 'AT': bf}, ignore_index= True)
                
                #Definizione delle caratteristiche del plot del fit lineare.
                ax[row, col].plot(x, y, color= 'darkred')
                ax[row, col].scatter(pt, 500, marker= 'o', color= 'darkgreen')
                ax[row, col].set_ylim((-50, 1050))
                ax[row, col].grid()
                ax[row, col].set_title('Channel_{:d}'.format(i), fontsize= '9')
                ax[row, col].annotate('Transition\nPoint', fontsize= '8', xy=(pt, 500), xytext=(pt-8, 525))
                ax[row, col].arrow(pt-3.5, 545, 3.5, -45)
                
                #Contatori e gestione delle posizioni dei plot dei channel.
                c= c+self.num['L'][j]
                j+= 1
                col+= 1
                if col== 4:
                    col= 0
                    row +=1

            diff= plot_count

            fig.tight_layout(h_pad= 1.08, w_pad= 0.3)
            plt.close()

    def results(self):
        #Metodo per il calcolo dei risultati e degli istogrammi di confronto.

        #Calcolo delle medie dei PT e AT.
        f_pt_mean= sum(self.f_res['PT'])/len(self.f_res)
        f_at_mean= sum(self.f_res['AT'])/len(self.f_res)
        l_pt_mean= sum(self.l_res['PT'])/len(self.l_res)
        l_at_mean= sum(self.l_res['AT'])/len(self.l_res)
        c_pt_mean= sum(self.c_res['PT'])/len(self.c_res)
        c_at_mean= sum(self.c_res['AT'])/len(self.c_res)
        
        print("""
file PT and AT mean: {:f}, {:f};
l_fit PT and AT mean: {:f}, {:f};
c_fit PT and AT mean: {:f}, {:f};
        """.format(f_pt_mean, f_at_mean, l_pt_mean, l_at_mean, c_pt_mean, c_at_mean))
        print('l-fit data discarded: {:d}'.format(len(self.f_res)-len(self.l_res)))

        #Definizione degli istogrammi per le distribuzioni.
        fig, ax= plt.subplots(3,1, tight_layout= True)
        amp, ay= plt.subplots(3,1, tight_layout= True)

        ax[0].hist(self.f_res['PT'], bins=200)
        ax[0].set_title('files_transition_points_distribution')
        ax[0].text(100, 400, 'mean: {:.3f}'.format(f_pt_mean))
        
        ax[1].hist(self.l_res['PT'], bins=200)
        ax[1].set_title('linear_fit_transition_points_distribution')
        ax[1].text(50,750, 'mean: {:.3f}'.format(l_pt_mean))
        
        ax[2].hist(self.c_res['PT'], bins=200)
        ax[2].set_title('curve_fit_transition_points_distribution')
        ax[2].text(100, 400, 'mean: {:.3f}'.format(c_pt_mean))
        
        ay[0].hist(self.f_res['AT'], bins=200)
        ay[0].set_title('files_trans_ampl_distribution')
        ay[0].text(10, 10000, 'mean: {:.3f}'.format(f_at_mean))

        ay[1].hist(self.l_res['AT'], bins=200)
        ay[1].set_title('linear_fit_trans_ampl_distribution')
        ay[1].text(-1500, 25000, 'mean: {:.3f}'.format(l_at_mean))

        ay[2].hist(self.c_res['AT'], bins=200)
        ay[2].set_title('curve_fit_trans_ampl_distribution')
        ay[2].text(7.5, 10000, 'mean: {:.3f}'.format(c_at_mean))

        plt.show()