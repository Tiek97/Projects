#Questo file permette, importando quello contenente la classe
#e le helper function, di lanciare il programma chiamando solo
#il necessario, rendendo più facile il cambio di eventuali parametri
#e l'utilizzo da parte dei fruitori non interessati ai processi
#svolti dal programma.

import claro as cl


filename= 'data_found.txt'
cl_an= cl.analyzer()

print('searching data...')
cl_an.finder(filename)
print('plotting data...')
cl_an.plotter()
print('plotting results...')
cl_an.results()

